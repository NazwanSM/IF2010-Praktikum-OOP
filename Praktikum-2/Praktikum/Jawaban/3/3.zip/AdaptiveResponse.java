/*
    Nama                    : 
    NIM                     : 
    Hari dan tanggal        : 
    Deskripsi Program       :
*/

/**
 * AdaptiveResponse.java
 * 
 * Interface untuk mendefinisikan respon adaptif atau perilaku khusus bakteri.
 */
public interface AdaptiveResponse {
    void doAdaptiveResponse();
}
