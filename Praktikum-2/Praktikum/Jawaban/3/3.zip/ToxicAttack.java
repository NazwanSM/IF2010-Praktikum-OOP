/*
    Nama                    : 
    NIM                     : 
    Hari dan tanggal        : 
    Deskripsi Program       :
*/

/**
 * ToxicAttack.java
 * 
 * Interface untuk bakteri yang dapat melakukan serangan toksik.
 */
public interface ToxicAttack {
    void toxicAttack(BacteriaBehaviour target);
}
