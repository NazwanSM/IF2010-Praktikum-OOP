public class PaketDewasa extends Makanan {
    /**
     * Konstruktor
     */
    public PaketDewasa() {
        super("Oseng Tempe", 250, "Es Teh Manis");

    }

}