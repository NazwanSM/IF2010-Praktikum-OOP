import java.util.ArrayList;
import java.util.Scanner;

public class BukanOlympia {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Membaca input awal
        String namaBahasa = scanner.next();
        int jumlahFile = scanner.nextInt();
        ArrayList<String> files = new ArrayList<>();
        for (int i = 0; i < jumlahFile; i++) {
            files.add(scanner.next());
        }

        try {
            // Panggil factory untuk mendapatkan runner bahasa yang sesuai
            Bahasa runner = BahasaFactory.getBahasaRunner(namaBahasa, files);
            
            // Lakukan kompilasi
            runner.compile();
            
            // Membaca input testcase
            int jumlahTestcase = scanner.nextInt();
            for (int i = 0; i < jumlahTestcase; i++) {
                String inputFile = scanner.next();
                String outputFile = scanner.next();

                // Coba jalankan grading untuk setiap testcase
                try {
                    runner.grade(inputFile, outputFile);
                } catch (BahasaError e) {
                    // Jika ada error pada grading, cetak pesan dan lanjut ke testcase berikutnya
                    System.out.println(e.getMessage());
                }
            }

        } catch (BahasaError e) {
            // Jika ada error pada setup (getBahasaRunner atau compile), cetak pesan dan keluar
            System.out.println(e.getMessage());
        }

        scanner.close();
    }
}